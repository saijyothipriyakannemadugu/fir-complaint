import React from 'react';
import { FileText } from 'lucide-react';
import ComplaintForm from './components/ComplaintForm';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <FileText className="h-8 w-8 text-blue-600" />
              <h1 className="ml-2 text-2xl font-bold text-gray-900">Online Complaint Registration</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="bg-white px-4 py-5 shadow sm:rounded-lg sm:p-6">
          <div className="md:grid md:grid-cols-3 md:gap-6">
            <div className="md:col-span-1">
              <h3 className="text-lg font-medium leading-6 text-gray-900">File a Complaint</h3>
              <p className="mt-1 text-sm text-gray-500">
                Please provide accurate information to help us process your complaint effectively.
                All fields marked with an asterisk (*) are required.
              </p>
              <div className="mt-6">
                <h4 className="text-sm font-medium text-gray-900">Important Notice:</h4>
                <ul className="mt-2 text-sm text-gray-500 list-disc list-inside space-y-1">
                  <li>False complaints are punishable by law</li>
                  <li>Your information will be kept confidential</li>
                  <li>You will receive a complaint reference number</li>
                </ul>
              </div>
            </div>
            <div className="mt-5 md:col-span-2 md:mt-0">
              <ComplaintForm />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;