import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { FileText, MapPin, Clock, User, Phone, Mail, Shield, AlertCircle, Building2, FileCheck } from 'lucide-react';
import type { ComplaintForm } from '../types';
import SuccessPopup from './SuccessPopup';

export default function ComplaintForm() {
  const [showSuccess, setShowSuccess] = useState(false);
  const [complaintNumber, setComplaintNumber] = useState('');
  const { register, handleSubmit, watch, formState: { errors } } = useForm<ComplaintForm>();

  const previouslyReported = watch('previouslyReported');

  const generateComplaintNumber = () => {
    const date = new Date();
    const year = date.getFullYear();
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    return `FIR${year}${random}`;
  };

  const onSubmit = (data: ComplaintForm) => {
    console.log(data);
    const number = generateComplaintNumber();
    setComplaintNumber(number);
    setShowSuccess(true);
  };

  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* Personal Information Section */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <User className="w-5 h-5" />
            Personal Information
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Full Name *</label>
              <input
                type="text"
                {...register('fullName', { required: 'Full name is required' })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              {errors.fullName && <p className="text-red-500 text-sm mt-1">{errors.fullName.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Email *</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                  <Mail className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="email"
                  {...register('email', { required: 'Email is required' })}
                  className="pl-10 block w-full rounded-md border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Phone *</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                  <Phone className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="tel"
                  {...register('phone', { required: 'Phone number is required' })}
                  className="pl-10 block w-full rounded-md border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Gender *</label>
              <select
                {...register('gender', { required: 'Gender is required' })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="">Select gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
              {errors.gender && <p className="text-red-500 text-sm mt-1">{errors.gender.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Age *</label>
              <input
                type="number"
                {...register('age', { required: 'Age is required', min: 18 })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              {errors.age && <p className="text-red-500 text-sm mt-1">{errors.age.message}</p>}
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700">Address *</label>
              <textarea
                {...register('address', { required: 'Address is required' })}
                rows={2}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              {errors.address && <p className="text-red-500 text-sm mt-1">{errors.address.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">ID Type *</label>
              <select
                {...register('idType', { required: 'ID type is required' })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="">Select ID type</option>
                <option value="passport">Passport</option>
                <option value="driverLicense">Driver's License</option>
                <option value="nationalId">National ID</option>
                <option value="other">Other</option>
              </select>
              {errors.idType && <p className="text-red-500 text-sm mt-1">{errors.idType.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">ID Number *</label>
              <input
                type="text"
                {...register('idNumber', { required: 'ID number is required' })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              {errors.idNumber && <p className="text-red-500 text-sm mt-1">{errors.idNumber.message}</p>}
            </div>
          </div>
        </div>

        {/* Complaint Details Section */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Complaint Details
          </h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Type of Complaint *</label>
              <select
                {...register('complaintType', { required: 'Please select a complaint type' })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="">Select type</option>
                <option value="theft">Theft</option>
                <option value="assault">Assault</option>
                <option value="fraud">Fraud</option>
                <option value="cybercrime">Cybercrime</option>
                <option value="other">Other</option>
              </select>
              {errors.complaintType && <p className="text-red-500 text-sm mt-1">{errors.complaintType.message}</p>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Incident Date *</label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                    <Clock className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="date"
                    {...register('incidentDate', { required: 'Incident date is required' })}
                    className="pl-10 block w-full rounded-md border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                {errors.incidentDate && <p className="text-red-500 text-sm mt-1">{errors.incidentDate.message}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Incident Time *</label>
                <input
                  type="time"
                  {...register('incidentTime', { required: 'Incident time is required' })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
                {errors.incidentTime && <p className="text-red-500 text-sm mt-1">{errors.incidentTime.message}</p>}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Incident Location *</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                  <MapPin className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  {...register('incidentLocation', { required: 'Location is required' })}
                  className="pl-10 block w-full rounded-md border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  placeholder="Enter the location of the incident"
                />
              </div>
              {errors.incidentLocation && <p className="text-red-500 text-sm mt-1">{errors.incidentLocation.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Police Station *</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                  <Building2 className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  {...register('policeStation', { required: 'Police station is required' })}
                  className="pl-10 block w-full rounded-md border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  placeholder="Enter the nearest police station"
                />
              </div>
              {errors.policeStation && <p className="text-red-500 text-sm mt-1">{errors.policeStation.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Detailed Description *</label>
              <textarea
                {...register('description', { required: 'Description is required', minLength: 50 })}
                rows={4}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="Please provide a detailed description of the incident..."
              />
              {errors.description && <p className="text-red-500 text-sm mt-1">{errors.description.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Suspect Details (if any)</label>
              <textarea
                {...register('suspectDetails')}
                rows={3}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="Provide any details about the suspect(s)..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Evidence Description</label>
              <textarea
                {...register('evidenceDescription')}
                rows={2}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="Describe any evidence you have (photos, documents, etc.)..."
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Witness Name</label>
                <input
                  type="text"
                  {...register('witnessName')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Witness Contact</label>
                <input
                  type="text"
                  {...register('witnessContact')}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <div className="flex items-start">
                <input
                  type="checkbox"
                  {...register('previouslyReported')}
                  className="mt-1 h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <label className="ml-2 block text-sm text-gray-700">
                  Has this incident been previously reported to the police?
                </label>
              </div>

              {previouslyReported && (
                <div className="mt-3">
                  <label className="block text-sm font-medium text-gray-700">Previous Report Details</label>
                  <textarea
                    {...register('previousReportDetails')}
                    rows={2}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    placeholder="Please provide details about the previous report..."
                  />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Consent Section */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Declaration & Consent
          </h2>
          <div className="space-y-4">
            <div className="flex items-start">
              <input
                type="checkbox"
                {...register('declaration', { required: 'You must agree to the declaration' })}
                className="mt-1 h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <label className="ml-2 block text-sm text-gray-700">
                I declare that the information provided above is true and accurate to the best of my knowledge.
                I understand that making a false complaint is a punishable offense under the law.
              </label>
            </div>
            {errors.declaration && <p className="text-red-500 text-sm">{errors.declaration.message}</p>}

            <div className="flex items-start">
              <input
                type="checkbox"
                {...register('privacyConsent', { required: 'You must agree to the privacy policy' })}
                className="mt-1 h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <label className="ml-2 block text-sm text-gray-700">
                I consent to the collection and processing of my personal information for the purpose of this complaint.
                I understand that this information may be shared with relevant law enforcement agencies.
              </label>
            </div>
            {errors.privacyConsent && <p className="text-red-500 text-sm">{errors.privacyConsent.message}</p>}
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            Submit Complaint
          </button>
        </div>
      </form>

      <SuccessPopup
        isOpen={showSuccess}
        onClose={() => setShowSuccess(false)}
        complaintNumber={complaintNumber}
      />
    </>
  );
}