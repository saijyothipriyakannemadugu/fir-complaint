import React from 'react';
import { CheckCircle, X } from 'lucide-react';
import type { SuccessPopupProps } from '../types';

export default function SuccessPopup({ isOpen, onClose, complaintNumber }: SuccessPopupProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 max-w-md w-full mx-4 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
        >
          <X className="h-6 w-6" />
        </button>
        
        <div className="flex flex-col items-center text-center">
          <CheckCircle className="h-16 w-16 text-green-500 mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Complaint Registered Successfully</h2>
          <p className="text-gray-600 mb-6">
            Your complaint has been registered. Please save this number for future reference.
          </p>
          
          <div className="bg-gray-50 rounded-lg p-4 mb-6 w-full">
            <p className="text-sm text-gray-600 mb-2">Complaint Reference Number:</p>
            <p className="text-2xl font-mono font-bold text-blue-600">{complaintNumber}</p>
          </div>
          
          <div className="text-sm text-gray-500">
            <p>A confirmation email has been sent to your registered email address.</p>
            <p>You can use this number to track your complaint status.</p>
          </div>
        </div>
      </div>
    </div>
  );
}