export type ComplaintType = 'theft' | 'assault' | 'fraud' | 'cybercrime' | 'other';

export interface ComplaintForm {
  // Personal Information
  fullName: string;
  email: string;
  phone: string;
  gender: 'male' | 'female' | 'other';
  age: number;
  address: string;
  idType: 'passport' | 'driverLicense' | 'nationalId' | 'other';
  idNumber: string;

  // Complaint Details
  complaintType: ComplaintType;
  incidentDate: string;
  incidentTime: string;
  incidentLocation: string;
  description: string;
  suspectDetails: string;
  evidenceDescription: string;
  witnessName?: string;
  witnessContact?: string;
  policeStation: string;
  previouslyReported: boolean;
  previousReportDetails?: string;

  // Consent
  declaration: boolean;
  privacyConsent: boolean;
}

export interface SuccessPopupProps {
  isOpen: boolean;
  onClose: () => void;
  complaintNumber: string;
}